# biyoloji-oyunu
9. sınıf biyoloji oyunu
@media(max-width:600px){
  #game{width:90%; padding:15px;}
  #answers button{width:80%; font-size:18px;}
}
